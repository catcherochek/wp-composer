<?php
/**
 * Displays the menu icon and modal
 *
 * @package WordPress
 * @subpackage Twenty_Twenty
 * @since 1.0.0
 */

?>


<div class="main-menu f-right d-none d-lg-block">





    <nav>
        <ul id="navigation">
            <?php
            if ( has_nav_menu( 'expanded' ) ) {
                wp_nav_menu(
                    array(
                        'container'      => '',
                        'items_wrap'     => '%3$s',
                        'show_toggles'   => false,
                        'theme_location' => 'expanded',
                    )
                );
            }
            ?>

        </ul>
    </nav>
</div>



