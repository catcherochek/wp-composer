<?php
/**
 * Template Name: Main Page
 * Template Post Type: post, page
 *
 * @package WordPress
 * @subpackage Monwesta
 * @since 1.0
 */



get_template_part( 'mainpage' );


?>