<?php
/**
 * The template for displaying single posts and pages.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty
 * @since 1.0.0
 */

get_header();
monwesta_load_react();
//echo do_shortcode('[metaslider id="95"]');
//echo wp_get_upload_dir()['baseurl'];
//do_shortcode('[slide-anything id="105"]');
//echo do_shortcode('[URIS id=109]');
//do_shortcode('[slide-anything id="105"]');
//do_shortcode('[slide-anything id="105"]');



?>
<div id="app-react"></div>
<main id="site-content" role="main">

	<?php

	if ( have_posts() ) {

		while ( have_posts() ) {
			the_post();

			get_template_part( 'template-parts/content', get_post_type() );
		}
	}

	?>

</main><!-- #site-content -->

<?php get_template_part( 'template-parts/footer-menus-widgets' ); ?>

<?php get_footer(); ?>
