<?php
/**
 * Header file for the Monwesta WordPress default theme.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty
 * @since 1.0.0
 */

?><!DOCTYPE html>

<html class="no-js" <?php language_attributes(); ?>>

	<head>

		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1.0" >

		<link rel="profile" href="https://gmpg.org/xfn/11">

		<?php wp_head(); ?>

	</head>

	<body <?php body_class(); ?> style="overflow: visible;">

    <!-- Preloader Start -->
    <!-- TODO clear style="display: none;"  after js loaded -->
    <div id="preloader-active" style="/*display: none;*/">
        <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-inner position-relative">
                <div class="preloader-circle"></div>
                <div class="preloader-img pere-text">
                    <img src="<?php echo monwesta_get_images('logo_2699a72404984e13f95c7b934f031f6c_1x.png') ?>" alt="">
                </div>
            </div>
        </div>
    </div>

        <header>
            <!-- Header Start -->
            <div class="header-area">

                <div class="main-header ">
                    <div class="header-top top-bg d-none d-lg-block">
                        <div class="container-fluid">
                            <div class="col-xl-12">
                                <div class="row d-flex justify-content-between align-items-center">
                                    <div class="header-info-left">
                                        <ul>
                                            <li><i class="fas fa-map-marker-alt"></i><?php monwesta_text('set_address'); ?></li>
                                            <li><i class="fas fa-envelope"></i><?php monwesta_text('set_email'); ?></li>

                                        </ul>
                                    </div>
                                    <div class="header-info-right">
                                        <ul class="header-social">
                                            <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                            <li> <a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="header-bottom  header-sticky" style =" border-bottom:2px solid grey;">
                        <div class="container-fluid">
                            <div class="row align-items-center">
                                <!-- Logo -->
                                <div class="col-xl-2 col-lg-1 col-md-1">
                                    <div class="logo">
                                        <?php
                                        // Site title or logo.
                                        twentytwenty_site_logo();

                                        // Site description.
                                        twentytwenty_site_description();


                                        ?>
                                    </div>
                                </div>
                                <div class="col-xl-8 col-lg-8 col-md-8">
                                    <!-- Main-menu -->
                                    <?php
		                                // Output the menu modal.
                                    get_template_part( 'template-parts/modal-menu' );?>


                                </div>
                                <div class="col-xl-2 col-lg-3 col-md-3">
                                    <div class="header-right-btn f-right d-none d-lg-block">
                                        <a href="#" class="btn header-btn">Contact Now</a>
                                    </div>
                                </div>
                                <!-- Mobile Menu -->
                                <div class="col-12">
                                    <div class="mobile_menu d-block d-lg-none"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Header End -->
        </header>


